# Ejercicios PHP
 - Crea un ejercicio de API REST en php y pon en práctica un proceso básico de autentificación con PHP y MySQL sin usar ningún framework ni librería.
 - Tener en cuenta el uso de POST, PUT, DELETE y GET.
 - Montar CRUD en plantilla básica de HTML y aplicar estilos (CSS)
 - Documentar
